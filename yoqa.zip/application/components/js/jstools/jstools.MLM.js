(function ( $ ) {
 
    $.MLM = function(data)
    {
    	
    }
    $.MLM.options = {
        toggle_templates: '<a>' 
    }
 
}( jQuery ));