(function ( $ ) {
 
    $.fn.counter = function(value)
    {
    	this.text(value);
    	return this;
    }
 
}( jQuery ));